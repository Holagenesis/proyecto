YUI().use("gallery-lightbox", function (Y) { Y.Lightbox.init(); });
